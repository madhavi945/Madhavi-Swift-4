import UIKit
//Base class:Monster.Creating a base protocol with common properties.
class Monster {
    private var name: String
    private var isAlive: Bool = true
    
    init(name: String) {
        self.name = name
    }
    //getter(s)
    func getName() -> String {
        return self.name
    }
    func getIsAlive() -> Bool {
        return self.isAlive
    }
    func speak() {
        print("Generic monster noise")
    }
    //setter(s)
    func setName(name: String) {
        self.name = name
    }
    func killMonster() {
        self.isAlive = false
    }
}
    //FlyingMonster class.Defining child protocols
    class FlyingMonster: Monster {
        private var wingSpan:Double
        
        init(name: String, wingSpan: Double) {
            self.wingSpan = wingSpan
            super.init(name: name)
        }
        //getter(s)
        func getWingSpan() -> Double {
            return self.wingSpan
        }
        func fly() {
            print("\(getName()) spreads its  \(wingSpan)-meter wings and takes to the sky! ")
        }
    }
    //WaterMonster class .creating subclass of Monster
    class WaterMonster: Monster {
        private var swimSpeed:Int
        
        init(name: String, swimSpeed: Int) {
            self.swimSpeed = swimSpeed
            super.init(name: name)
        }
        //getter(s)
        func getSwimSpeed() -> Int {
            return self.swimSpeed
        }
        func swim() {
            print("\(getName()) glides through the water at \(swimSpeed) knots")
        }
    }
    //Defining dragon class for specific implementation of flyingMonster.
    class Dragon: FlyingMonster {
        override func speak() {
            print("\(getName()) roars fiercely,shaking the ground!")
        }
    }
    //Defining gryphon class for specific implementation of FlyingMonster.
    class Gryphon: FlyingMonster {
        override func speak() {
            print("\(getName()) screeches with a piercing cry!")
        }
    }
    //Defining kraken class for specific implementation of a WaterMonster.
    class Kraken: WaterMonster {
        override func speak() {
            print("\(getName()) bellows from the deep,causing waves to crash!")
        }
    }
    //Defining Merfolk class for implementation of a watermonster.
    class Merfolk: WaterMonster {
        override func speak() {
            print("\(getName()) sings an enchanting melody that stirs the seas!")
        }
    }
    //Creating a function that accepts a collection of monster objects and print deatils by using polymorphism.
    func printMonsterDetails(monsters: [Monster]) {
        for monster in monsters {
            monster.speak()
            if let flyingMonster = monster as? FlyingMonster {
                flyingMonster.fly()
            }
            else if let waterMonster = monster as? WaterMonster {
                waterMonster.swim()
            }
            print("---------------")
        }
    }
    //========== Object Creation and Testing ============>>>
    func main() {
        let fireDrake = Dragon(name:"fire Drake",wingSpan: 15.0)
        let skyHunter = Gryphon(name: "sky Hunter",wingSpan: 12.0)
        let seaTerror = Kraken(name: "sea Terror",swimSpeed: 20)
        let coralQueen = Merfolk(name: "coral Queen",swimSpeed: 10)
        
        let monsters: [Monster] = [fireDrake, skyHunter, seaTerror, coralQueen]
        printMonsterDetails(monsters: monsters)
        
    }
main()

